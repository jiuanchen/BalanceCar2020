/**
  ******************************************************************************
  * @file    GPIO/IOToggle/stm32f10x_it.c 
  * @author  MCD Application Team
  * @version V3.5.0
  * @date    08-April-2011
  * @brief   Main Interrupt Service Routines.
  *          This file provides template for all exceptions handler and peripherals
  *          interrupt service routine.
  ******************************************************************************
  * @attention
  *
  * THE PRESENT FIRMWARE WHICH IS FOR GUIDANCE ONLY AIMS AT PROVIDING CUSTOMERS
  * WITH CODING INFORMATION REGARDING THEIR PRODUCTS IN ORDER FOR THEM TO SAVE
  * TIME. AS A RESULT, STMICROELECTRONICS SHALL NOT BE HELD LIABLE FOR ANY
  * DIRECT, INDIRECT OR CONSEQUENTIAL DAMAGES WITH RESPECT TO ANY CLAIMS ARISING
  * FROM THE CONTENT OF SUCH FIRMWARE AND/OR THE USE MADE BY CUSTOMERS OF THE
  * CODING INFORMATION CONTAINED HEREIN IN CONNECTION WITH THEIR PRODUCTS.
  *
  * <h2><center>&copy; COPYRIGHT 2011 STMicroelectronics</center></h2>
  ******************************************************************************
  */

/* Includes ------------------------------------------------------------------*/
#include "stm32f10x_it.h" 
#include "mpu6050.h"
#include "systick.h"
#include <stdio.h>
#include "control.h"
#include "led.h"
#include "oled.h"

uint8_t sys_sec=0;
uint8_t start_cnt_flag=1;
uint8_t run_flag=0;


void NMI_Handler(void)
{
}
 
void HardFault_Handler(void)
{
  /* Go to infinite loop when Hard Fault exception occurs */
  while (1)
  {
  }
}
 
void MemManage_Handler(void)
{
  /* Go to infinite loop when Memory Manage exception occurs */
  while (1)
  {
  }
}

 
void BusFault_Handler(void)
{
  /* Go to infinite loop when Bus Fault exception occurs */
  while (1)
  {
  }
}
 
void UsageFault_Handler(void)
{
  /* Go to infinite loop when Usage Fault exception occurs */
  while (1)
  {
  }
}
 
void SVC_Handler(void)
{
}
 
void DebugMon_Handler(void)
{
}
 
void PendSV_Handler(void)
{
}


void SysTick_Handler(void)
{
	static uint32_t cnt;
	
	
	cnt++;
	
	if(start_cnt_flag)
	{
		if(cnt>=1000)
		{
			cnt=0;
			
			sys_sec++;
			if(sys_sec>3)
			{
				run_flag=1;
				start_cnt_flag=0;
				g_iCarSpeedSet=15;
			}	
		}	
	}
	
//	static uint32_t cnt;
//	static uint8_t led_flag=0;
//	
//	cnt++;
//	if(cnt>=1000)
//	{
//		cnt=0;
//		if(led_flag)
//		{
//			LED3_OFF;
//			led_flag=~led_flag;
//		}
//		else
//		{
//			LED3_ON;
//			led_flag=~led_flag;
//		}
//	}/////���Զ�ʱ����û����������
	SoftTimerCountDown();			 //����ʱ��
	g_u8MainEventCount++;
	g_u8SpeedControlPeriod++;  
	SpeedControlOutput();   		 //�ٶȻ��������������ÿ1msִ��һ��
	if(g_u8MainEventCount>=5)
	{
		g_u8MainEventCount=0;
		GetMotorPulse();			 //���������壨�ٶȣ�������ÿ5msִ��һ��
	}
	else if(g_u8MainEventCount==1)
	{
		MPU6050_Pose();				 //��ȡMPU6050���ݺ�����ÿ5msִ��һ��
		AngleCalculate();			 //�ǶȻ����㺯����ÿ5msִ��һ��
	}
	else if(g_u8MainEventCount==2)
	{
		AngleControl();				 //�ǶȻ����ƺ�����ÿ5msִ��һ��

	}
	else if(g_u8MainEventCount==3)
	{
		g_u8SpeedControlCount++;
    	if(g_u8SpeedControlCount >= 5)//25ms
    	{		
      	SpeedControl();          //��ģ�ٶȿ��ƺ�����ÿ25ms����һ��
				if(run_flag)
				{
					dircontrol();
				}
      	g_u8SpeedControlCount=0;
			  g_u8SpeedControlPeriod=0;
    	}
	}
	else if(g_u8MainEventCount==4)
	{
		MotorManage();			//���ʹ��/ʧ�ܿ��ƺ�����ÿ5msִ��һ��
		
		MotorOutput();	 		//������������ÿ5msִ��һ��
		
	}	
	
}

/******************************************************************************/
/*                 STM32F10x Peripherals Interrupt Handlers                   */
/*  Add here the Interrupt Handler for the used peripheral(s) (PPP), for the  */
/*  available peripheral interrupt handler's name please refer to the startup */
/*  file (startup_stm32f10x_xx.s).                                            */
/******************************************************************************/
