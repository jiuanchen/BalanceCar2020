
#ifndef __MOTOR_H
#define __MOTOR_H


void TIM3_PWM_Init(void);

void TIM2_Encoder_Init(void);
void TIM4_Encoder_Init(void);


#endif

